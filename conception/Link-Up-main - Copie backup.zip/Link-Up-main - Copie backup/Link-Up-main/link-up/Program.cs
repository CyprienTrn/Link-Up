using link_up.Services;
using link_up.Routes;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Lecture des configurations JWT depuis appsettings.json
var jwtIssuer = builder.Configuration["Jwt:Issuer"] ?? "JwtIssuer";
var jwtAudience = builder.Configuration["Jwt:Audience"] ?? "JwtAudience";
var jwtKey = builder.Configuration["Jwt:Key"] ?? "YourSuperSecretKey123!";

if (string.IsNullOrEmpty(jwtIssuer) || string.IsNullOrEmpty(jwtAudience) || string.IsNullOrEmpty(jwtKey))
{
    throw new Exception("Les paramètres Jwt:Issuer, Jwt:Audience ou Jwt:Key sont manquants dans appsettings.json.");
}

// Ajouter les services nécessaires
builder.Services.AddSingleton<UserCosmosService>();
builder.Services.AddSingleton<MediaCosmosService>();
builder.Services.AddSingleton<ContentCosmosService>();
builder.Services.AddSingleton(new JwtService(jwtKey, jwtIssuer, jwtAudience));

builder.Services.AddControllers();

// Ajouter l'authentification JWT
builder.Services.AddAuthentication("Bearer")
    .AddJwtBearer("Bearer", options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = jwtIssuer,
            ValidAudience = jwtAudience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey))
        };
    });

// Ajouter l'autorisation
builder.Services.AddAuthorization();

// Ajouter Swagger et configurer JWT dans Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Link-Up API", Version = "1.0" });

    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Insérez le token JWT dans le format : Bearer <token>"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });

    c.TagActionsBy(api => api.GroupName != null ? new[] { api.GroupName } : new[] { "Default" });
});

var app = builder.Build();

// Configurer le pipeline HTTP
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

// Map des routes
app.MapGroup("/utilisateurs")
   .WithTags("Utilisateurs")
   .MapUserRoutes();

app.MapGroup("/contenus")
   .WithTags("Contenus")
   .MapContentRoutes();

app.MapGroup("/medias")
   .WithTags("Médias")
   .MapMediaRoutes();

// Inclure AuthController dans MapControllers
app.MapControllers();

app.Run();
