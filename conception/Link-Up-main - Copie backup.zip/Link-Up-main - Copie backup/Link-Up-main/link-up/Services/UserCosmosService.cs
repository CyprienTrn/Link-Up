using Microsoft.Azure.Cosmos;
using System.Net;
using UserApp = link_up.Models.User;
using link_up.DTO;

namespace link_up.Services
{
    public class UserCosmosService
    {
        private readonly CosmosClient _cosmosClient;
        private readonly Database _database;
        private readonly Container _container;
        private string _userPartitionKey;

        public UserCosmosService(IConfiguration configuration)
        {
            var cosmosSettings = configuration.GetSection("CosmosDbCyp");
            string endpointUri = cosmosSettings["EndpointUri"];
            string primaryKey = cosmosSettings["PrimaryKey"];
            string databaseId = cosmosSettings["DatabaseId"];
            string containerId = cosmosSettings["ContainerUserId"];
            _userPartitionKey = cosmosSettings["UserPartitionKey"];

            _cosmosClient = new CosmosClient(endpointUri, primaryKey, new CosmosClientOptions { ApplicationName = "LinkUpApp" });
            _database = _cosmosClient.CreateDatabaseIfNotExistsAsync(databaseId).Result;
            ContainerProperties containerProperties = new ContainerProperties()
            {
                Id = containerId,
                PartitionKeyPath = _userPartitionKey,
            };
            _container = _database.CreateContainerIfNotExistsAsync(containerProperties).Result;
        }

        // Récupérer tous les utilisateurs
        public async Task<IEnumerable<UserDTO>> GetAllUtilisateursAsync()
        {
            var query = "SELECT c.id, c.Email, c.Name, c.IsPrivate, c.CreatedAt FROM c";
            var queryDefinition = new QueryDefinition(query);
            var queryResultSetIterator = _container.GetItemQueryIterator<UserDTO>(queryDefinition);

            var users = new List<UserDTO>();
            while (queryResultSetIterator.HasMoreResults)
            {
                var currentResultSet = await queryResultSetIterator.ReadNextAsync();
                users.AddRange(currentResultSet);
            }
            return users;
        }

        // Vérifier si l'email est valide et unique
        public async Task<bool> IsEmailValidAndUniqueAsync(string email)
        {
            if (string.IsNullOrWhiteSpace(email) || !IsValidEmail(email))
            {
                throw new ArgumentException("L'email fourni n'est pas valide.");
            }

            var query = "SELECT COUNT(1) FROM c WHERE c.Email = @Email";
            var queryDefinition = new QueryDefinition(query)
                .WithParameter("@Email", email);

            var queryIterator = _container.GetItemQueryIterator<int>(queryDefinition);

            while (queryIterator.HasMoreResults)
            {
                var resultSet = await queryIterator.ReadNextAsync();
                if (resultSet.FirstOrDefault() > 0)
                {
                    return false;
                }
            }

            return true;
        }

        // Vérifier si un email est valide
        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                if (addr.Address != email)
                    return false;

                // Validation avec expression régulière
                string emailPattern = @"^[^@\s]+@[^@\s]+\.[a-zA-Z]{2,}$";
                return System.Text.RegularExpressions.Regex.IsMatch(email, emailPattern);
            }
            catch
            {
                return false;
            }
        }

        // Créer un utilisateur
        public async Task<UserApp> CreateUserAsync(UserApp user)
        {
            try
            {
                // Générer un id unique à chaque utilisateur
                user.id = Guid.NewGuid().ToString();

                // Assigner la clé de partition
                user.user_id = this._userPartitionKey;

                if (!this.IsValidEmail(user.Email))
                {
                    throw new InvalidOperationException("L'email saisi n'est pas valide");
                }

                user.CreatedAt = DateTime.UtcNow;
                var response = await _container.CreateItemAsync(user, new PartitionKey(user.user_id));

                return response.Resource;
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.Conflict)
            {
                throw new Exception($"User with ID {user.id} already exists.", ex);
            }
        }

        // Récupérer un utilisateur par ID
        public async Task<UserApp?> GetUserByIdAsync(string userId)
        {
            try
            {
                var response = await _container.ReadItemAsync<UserApp>(userId, new PartitionKey(this._userPartitionKey));
                return response.Resource;
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }
        }

        // Récupérer un utilisateur par Email
        public async Task<UserApp?> GetUserByEmailAsync(string email)
        {
            var query = "SELECT * FROM c WHERE c.Email = @Email";
            var queryDefinition = new QueryDefinition(query).WithParameter("@Email", email);
            var queryIterator = _container.GetItemQueryIterator<UserApp>(queryDefinition);

            while (queryIterator.HasMoreResults)
            {
                var currentResultSet = await queryIterator.ReadNextAsync();
                return currentResultSet.FirstOrDefault();
            }

            return null;
        }

        // Mettre à jour un utilisateur
        public async Task<UserApp> UpdateUserAsync(string userId, UserApp updatedUser)
        {
            try
            {
                var user = await GetUserByIdAsync(userId);
                if (user == null) throw new Exception($"User with ID {userId} not found.");

                user.Email = updatedUser.Email ?? user.Email;
                user.Name = updatedUser.Name ?? user.Name;
                user.IsPrivate = updatedUser.IsPrivate;

                var response = await _container.ReplaceItemAsync(user, user.id.ToString(), new PartitionKey(this._userPartitionKey));
                return response.Resource;
            }
            catch (CosmosException ex)
            {
                Console.WriteLine($"An error occurred while updating the user: {ex.Message}");
                throw;
            }
        }

        // Supprimer un utilisateur
        public async Task DeleteUserAsync(string userId)
        {
            try
            {
                await _container.DeleteItemAsync<UserApp>(userId, new PartitionKey(this._userPartitionKey));
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                throw new Exception($"User with ID {userId} not found.", ex);
            }
        }

        // Vérifier l'existence d'un utilisateur
        public async Task<bool> CheckUserExistsAsync(string userId)
        {
            try
            {
                var response = await _container.ReadItemAsync<UserApp>(userId, new PartitionKey("/user_id"));
                return response.Resource != null;
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                return false;
            }
        }
    }
}
