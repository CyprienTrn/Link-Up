using Newtonsoft.Json;

namespace link_up.DTO
{
    public class UserDTO
    {
        public string id { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
        public bool IsPrivate { get; set; }
        public DateTime CreatedAt { get; set; }

        // Ignore le mot de passe dans le DTO
        [JsonIgnore]
        public string Password { get; set; }
    }
}
