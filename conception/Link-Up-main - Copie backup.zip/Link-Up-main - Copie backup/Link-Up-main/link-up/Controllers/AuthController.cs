using Microsoft.AspNetCore.Mvc;
using link_up.Services;
using link_up.Models;
using System.Threading.Tasks;
using BCrypt.Net;
using Newtonsoft.Json;

namespace link_up.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly JwtService _jwtService;
        private readonly UserCosmosService _userCosmosService;

        public AuthController(JwtService jwtService, UserCosmosService userCosmosService)
        {
            _jwtService = jwtService;
            _userCosmosService = userCosmosService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            if (string.IsNullOrEmpty(request.Email) || string.IsNullOrEmpty(request.Password))
            {
                return BadRequest(new { message = "Email and Password are required" });
            }

            // Recherche l'utilisateur par email
            var user = await _userCosmosService.GetUserByEmailAsync(request.Email);

            if (user == null || !BCrypt.Net.BCrypt.Verify(request.Password, user.Password))
            {
                return Unauthorized(new { message = "Invalid credentials" });
            }

            // Génère un token JWT pour l'utilisateur
            var token = _jwtService.GenerateToken(user.id, user.Email);
            return Ok(new { Token = token });
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest request)
        {
            if (string.IsNullOrEmpty(request.Email) || string.IsNullOrEmpty(request.Password) || string.IsNullOrEmpty(request.Name))
            {
                return BadRequest(new { message = "Email, Password, and Name are required" });
            }

            // Vérifier si l'email est valide et unique
            var isEmailUnique = await _userCosmosService.IsEmailValidAndUniqueAsync(request.Email);
            if (!isEmailUnique)
            {
                return Conflict(new { message = "Email already in use" });
            }

            // Créer un nouvel utilisateur avec le mot de passe haché
            var newUser = new User
            {
                Email = request.Email,
                Password = BCrypt.Net.BCrypt.HashPassword(request.Password), // Hachage du mot de passe
                CreatedAt = DateTime.UtcNow,
                Name = request.Name,
                IsPrivate = request.IsPrivate
            };

            try
            {
                // Créer l'utilisateur dans Cosmos DB
                var createdUser = await _userCosmosService.CreateUserAsync(newUser);
                return CreatedAtAction(nameof(Register), new { id = createdUser.id }, new { createdUser.id, createdUser.Email });
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la création
                return StatusCode(500, new { message = "An error occurred while creating the user", error = ex.Message });
            }
        }
    }

    public class LoginRequest
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class RegisterRequest
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public bool IsPrivate { get; set; }
    }
}
